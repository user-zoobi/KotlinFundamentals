package com.example.components

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.toolbar_menu,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId)
        {
            R.id.settings ->        Log.i("menu","item clicked")
            R.id.addAccount ->      Log.i("menu","item clicked")
            R.id.favourites ->      Log.i("menu","item clicked")
            R.id.feedback ->        Log.i("menu","item clicked")
            R.id.close ->           Log.i("menu","item clicked")
        }
        return true
    }
}